package simulationoftelephonesystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class LostCall extends javax.swing.JFrame {
    private final int MAX_LINKS = 3;
    private final int TOTAL_LINES = 8;
    private int secondsElapsed = 0;
    private Timer timer;
    private Random rand = new Random();
    private ArrayList<ArrivalCallDelay> arrivalCalls = new ArrayList<>();
    private ArrayList<ArrivalCallDelay> activeCalls = new ArrayList<>();
    private int[] lineStatus = new int[TOTAL_LINES + 1]; // Index 1-8

    public LostCall() {
        initComponents();
        initializeTables();
        generateInitialCalls();
        startClock();
    }

    private void generateInitialCalls() {
        for (int i = 0; i < 5; i++) {
            generateCall();
        }
        updateNextCallTable();
    }

    private void initializeTables() {
        // Initialize Lines table
        DefaultTableModel linesModel = (DefaultTableModel) jTable2.getModel();
        for (int i = 1; i <= TOTAL_LINES; i++) {
            linesModel.setValueAt(i, i-1, 0);
            linesModel.setValueAt(false, i-1, 1);
        }
        
        // Initialize Links table
        DefaultTableModel linksModel = (DefaultTableModel) jTable7.getModel();
        linksModel.setValueAt(MAX_LINKS, 0, 0);
        linksModel.setValueAt(0, 0, 1);
        
        // Initialize other tables
        DefaultTableModel nextCallModel = (DefaultTableModel) jTable1.getModel();
        nextCallModel.setValueAt("--", 0, 0);
        nextCallModel.setValueAt("--", 0, 1);
        nextCallModel.setValueAt("--", 0, 2);
        nextCallModel.setValueAt("--", 0, 3);
        
        DefaultTableModel activeCallsModel = (DefaultTableModel) jTable4.getModel();
        for (int i = 0; i < 3; i++) {
            activeCallsModel.setValueAt("--", i, 0);
            activeCallsModel.setValueAt("--", i, 1);
            activeCallsModel.setValueAt("--", i, 2);
        }
        
        DefaultTableModel countersModel = (DefaultTableModel) jTable5.getModel();
        countersModel.setValueAt(0, 0, 0);
        countersModel.setValueAt(0, 0, 1);
        countersModel.setValueAt(0, 0, 2);
        countersModel.setValueAt(0, 0, 3);
        
        DefaultTableModel clockModel = (DefaultTableModel) jTable6.getModel();
        clockModel.setValueAt("00:00:00", 0, 0);
    }

private void generateCall() {
    int from = getRandom(1, TOTAL_LINES);
    int to = getRandom(1, TOTAL_LINES);
    while (to == from) {
        to = getRandom(1, TOTAL_LINES); // avoid self-call
    }

    int length = getRandom(30, 180); // call duration in seconds
    int arrivalTime = secondsElapsed + getRandom(10, 60); // Always in future
    
    ArrivalCallDelay call = new ArrivalCallDelay(from, to, length, arrivalTime);
    arrivalCalls.add(call);
    
    // Sort calls by arrival time to ensure proper queue order
    arrivalCalls.sort((c1, c2) -> Integer.compare(c1.arrivalTime, c2.arrivalTime));
}

private void updateNextCallTable() {
    DefaultTableModel nextCallModel = (DefaultTableModel) jTable1.getModel();
    
    // Find the next future call
    ArrivalCallDelay nextFutureCall = null;
    for (ArrivalCallDelay call : arrivalCalls) {
        if (call.arrivalTime > secondsElapsed) {
            nextFutureCall = call;
            break;
        }
    }
    
    if (nextFutureCall != null) {
        nextCallModel.setValueAt(nextFutureCall.from, 0, 0);
        nextCallModel.setValueAt(nextFutureCall.to, 0, 1);
        nextCallModel.setValueAt(nextFutureCall.length + " sec", 0, 2);
        nextCallModel.setValueAt(formatTime(nextFutureCall.arrivalTime), 0, 3);
    } else {
        nextCallModel.setValueAt("--", 0, 0);
        nextCallModel.setValueAt("--", 0, 1);
        nextCallModel.setValueAt("--", 0, 2);
        nextCallModel.setValueAt("--", 0, 3);
    }
}

    private void startClock() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                secondsElapsed++;
                
                // Update clock display
                DefaultTableModel clockModel = (DefaultTableModel) jTable6.getModel();
                clockModel.setValueAt(formatTime(secondsElapsed), 0, 0);
                
                // Process active calls (check for completed calls)
                processActiveCalls();
                
                // Process arriving calls
                processArrivingCalls();
                
                // Update next call display
                updateNextCallTable();
                
                // Generate new calls if queue is empty and no active calls
                if (arrivalCalls.isEmpty() && activeCalls.isEmpty() && secondsElapsed % 30 == 0) {
                    for (int i = 0; i < 3; i++) generateCall();
                    updateNextCallTable();
                }
            }
        });
        timer.start();
    }
    
    private void processActiveCalls() {
        Iterator<ArrivalCallDelay> activeIter = activeCalls.iterator();
        while (activeIter.hasNext()) {
            ArrivalCallDelay call = activeIter.next();
            if (secondsElapsed >= call.getArrivalTimeInSeconds() + call.length) {
                // Call ended
                lineStatus[call.from] = 0;
                lineStatus[call.to] = 0;
                updateLineStatus(call.from, false);
                updateLineStatus(call.to, false);
                activeIter.remove();
                updateActiveCallsTable();
                
                // Update counters
                incrementCounter("PROCESSED");
                incrementCounter("COMPLETED");
            }
        }
    }
    
   private void processArrivingCalls() {
    // Process all calls that should have arrived by now
    while (!arrivalCalls.isEmpty()) {
        ArrivalCallDelay nextCall = arrivalCalls.get(0);
        
        // Only process calls whose arrival time <= current time
        if (nextCall.arrivalTime <= secondsElapsed) {
            if (activeCalls.size() < MAX_LINKS && 
                lineStatus[nextCall.from] == 0 && 
                lineStatus[nextCall.to] == 0) {
                
                // Connect the call
                activeCalls.add(nextCall);
                lineStatus[nextCall.from] = 1;
                lineStatus[nextCall.to] = 1;
                
                // Update UI
                updateLineStatus(nextCall.from, true);
                updateLineStatus(nextCall.to, true);
                updateActiveCallsTable();
                
                // Update links count
                DefaultTableModel linksModel = (DefaultTableModel) jTable7.getModel();
                linksModel.setValueAt(activeCalls.size(), 0, 1);
            } else {
                // Count as blocked/busy
                incrementCounter("PROCESSED");
                incrementCounter("BUSY");
            }
            
            // Remove from queue whether connected or blocked
            arrivalCalls.remove(0);
            updateNextCallTable();
        } else {
            // Remaining calls are in the future
            break;
        }
    }
}
    
private void updateActiveCallsTable() {
    DefaultTableModel activeCallsModel = (DefaultTableModel) jTable4.getModel();
    // Clear the table
    for (int i = 0; i < activeCallsModel.getRowCount(); i++) {
        activeCallsModel.setValueAt("--", i, 0);
        activeCallsModel.setValueAt("--", i, 1);
        activeCallsModel.setValueAt("--", i, 2);
    }
    
    // Only show calls that were properly moved from next call queue
    for (int i = 0; i < activeCalls.size() && i < 3; i++) {
        ArrivalCallDelay call = activeCalls.get(i);
        activeCallsModel.setValueAt(call.from, i, 0);
        activeCallsModel.setValueAt(call.to, i, 1);
        activeCallsModel.setValueAt(formatTime(call.getArrivalTimeInSeconds() + call.length), i, 2);
    }
}
    private void updateLineStatus(int line, boolean busy) {
        DefaultTableModel linesModel = (DefaultTableModel) jTable2.getModel();
        linesModel.setValueAt(busy, line-1, 1);
    }
    
    private void incrementCounter(String counterType) {
        DefaultTableModel countersModel = (DefaultTableModel) jTable5.getModel();
        int col = -1;
        switch(counterType) {
            case "PROCESSED": col = 0; break;
            case "COMPLETED": col = 1; break;
            case "BLOCKED": col = 2; break;
            case "BUSY": col = 3; break;
        }
        
        if (col >= 0) {
            Integer current = (Integer) countersModel.getValueAt(0, col);
            if (current == null) current = 0;
            countersModel.setValueAt(current + 1, 0, col);
        }
    }
    
    private int getRandom(int min, int max) {
        return rand.nextInt((max - min) + 1) + min;
    }
    
    private String formatTime(int totalSeconds) {
        int h = totalSeconds / 3600;
        int m = (totalSeconds % 3600) / 60;
        int s = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }
class ArrivalCallDelay {
        int from;
        int to;
        int length; // in seconds
        int arrivalTime; // in seconds
        
        public ArrivalCallDelay(int from, int to, int length, int arrivalTime) {
            this.from = from;
            this.to = to;
            this.length = length;
            this.arrivalTime = arrivalTime;
        }
        
        public int getArrivalTimeInSeconds() {
            return arrivalTime;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(153, 255, 153));

        jTable2.setAutoCreateRowSorter(true);
        jTable2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Integer(1), null},
                { new Integer(2), null},
                { new Integer(3), null},
                { new Integer(4), null},
                { new Integer(5), null},
                { new Integer(6), null},
                { new Integer(7), null},
                { new Integer(8), null}
            },
            new String [] {
                "Telephone Lines", "Active Lines"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable2.setFocusable(false);
        jTable2.setShowGrid(true);
        jScrollPane2.setViewportView(jTable2);

        jTable4.setAutoCreateRowSorter(true);
        jTable4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "From", "To", "End"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setSelectionForeground(new java.awt.Color(51, 51, 51));
        jTable4.setShowGrid(true);
        jScrollPane4.setViewportView(jTable4);
        if (jTable4.getColumnModel().getColumnCount() > 0) {
            jTable4.getColumnModel().getColumn(2).setResizable(false);
        }

        jTable6.setAutoCreateRowSorter(true);
        jTable6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "CLOCK"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable6.setShowGrid(true);
        jScrollPane6.setViewportView(jTable6);

        jTable7.setAutoCreateRowSorter(true);
        jTable7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "Max Links", "Used Links"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.setShowGrid(true);
        jScrollPane7.setViewportView(jTable7);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Calls in progress");

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "FROM", "TO", "END", "ARRIVAL TIME"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setSelectionForeground(new java.awt.Color(102, 255, 102));
        jTable1.setShowGrid(true);
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Next arriving calls");

        jTable5.setAutoCreateRowSorter(true);
        jTable5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Processed", "Completed", "Blocked", "Busy"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.setShowGrid(true);
        jScrollPane5.setViewportView(jTable5);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("CALL COUNTERS");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("LOST CALL SYSTEM");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(244, 244, 244))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(31, 31, 31)
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(82, 82, 82)
                                        .addComponent(jLabel3)))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 97, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(260, 260, 260))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(166, 166, 166)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel4)
                .addGap(52, 52, 52)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LostCall.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LostCall.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LostCall.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LostCall.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LostCall().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    // End of variables declaration//GEN-END:variables

}