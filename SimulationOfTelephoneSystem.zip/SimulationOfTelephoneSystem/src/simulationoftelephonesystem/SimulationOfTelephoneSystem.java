package simulationoftelephonesystem;
public class SimulationOfTelephoneSystem {
    public static void main(String[] args) {
                new Home().setVisible(true);
    }
}
